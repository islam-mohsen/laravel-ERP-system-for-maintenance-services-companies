<?php

namespace Knp\Snappy\Exception;

class FileAlreadyExistsException extends \InvalidArgumentException
{
}
