<?php

namespace Yajra\DataTables\Html\Editor\Fields;

class ReadOnly extends Field
{
    protected $type = 'readonly';
}
