<?php

namespace Yajra\DataTables\Html\Editor\Fields;

class Password extends Field
{
    protected $type = 'password';
}
