<?php

namespace Yajra\DataTables\Html\Editor\Fields;

class TextArea extends Field
{
    protected $type = 'textarea';
}
