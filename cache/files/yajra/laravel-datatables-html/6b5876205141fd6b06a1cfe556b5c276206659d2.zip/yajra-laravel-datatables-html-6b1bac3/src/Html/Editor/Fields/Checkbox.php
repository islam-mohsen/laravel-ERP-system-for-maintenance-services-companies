<?php

namespace Yajra\DataTables\Html\Editor\Fields;

class Checkbox extends Field
{
    protected $type = 'checkbox';
}
